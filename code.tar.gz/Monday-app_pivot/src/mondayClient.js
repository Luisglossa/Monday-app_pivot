// src/mondayClient.js
import mondaySdk from "monday-sdk-js";
const monday = mondaySdk();
export default monday;